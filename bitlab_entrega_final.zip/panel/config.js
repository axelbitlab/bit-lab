const BTL_CONFIG = {
  supabase_url: "https://rtbvojodqgumlrlnbejn.supabase.co",
  supabase_key: "sb_publishable_gbm-2LN_-vPygLM3o9C8Gg_bT94CQLN",
};